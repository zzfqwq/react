import CheckinBooking from "../features/check-in-out/CheckinBooking";

function Checkin() {
  return <CheckinBooking />;
}

export default Checkin;
